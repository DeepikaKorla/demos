package com.cg.ems.model;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.cg.ems.beans.Employee;

//model interface
public interface EmployeeDAO extends JpaRepository<Employee,Integer>,CrudRepository<Employee,Integer> {
	
	

}
