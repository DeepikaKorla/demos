package com.cg.ems.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.ems.beans.Employee;
import com.cg.ems.exceptions.EMSException;
import com.cg.ems.model.EmployeeDAO;

//add EmployeeService interface
@Component(value="employeeService")
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired(required=true)
	private EmployeeDAO employeeDAO;

	@Override
	public int addEmployee(Employee employee) throws EMSException {


		employee= employeeDAO.save(employee);

		//		if( isvalid(employee)) {
		//
		//			empDAO.startTransaction();
		//			empId = empDAO.addEmployee(employee); //DAO generates id and sends to client
		//			empDAO.commitTransaction();
		//		}
		return employee.getId() ;
	}

	@Override
	public Employee getEmployee(int id) throws EMSException {

		//Employee employee = null; //accepting id
		//employee = empDAO.getEmployee(id); //DAO gets employee or raise the exception
		//		empDAO.startTransaction();
		//		empDAO.getEmployee(id);
		//		empDAO.commitTransaction();
		//		return empDAO.getEmployee(id); 
		Employee employee=employeeDAO.findOne(id);
		System.out.println(employee.getId() + employee.getName());
		return employee;
	}

	@Override
	public void updateEmployee(Employee employee) throws EMSException {

		//		empDAO.startTransaction();
		//		empDAO.updateEmployee(employee);
		//		empDAO.commitTransaction();
		employeeDAO.save(employee);
	}

	@Override
	public void removeEmployee(int id) throws EMSException {

		Employee employee = null; //emp ref var is null
		//employee = empDAO.removeEmployee(id);
		//		empDAO.startTransaction();
		//		empDAO.removeEmployee(id);
		//		empDAO.commitTransaction();
		//		return empDAO.removeEmployee(id); //return removed employee by DAO to client
		employeeDAO.delete(id);


	}

	@Override
	public List<Employee> getAllEmployees() throws EMSException {
		//List<Employee> employees = null;
		//employees = empDAO.getAllEmployees();
		//		empDAO.startTransaction();
		//		empDAO.getAllEmployees();
		//		empDAO.commitTransaction();
		return (List<Employee>) employeeDAO.findAll();

	}

	@Override
	public boolean isvalid(Employee employee) throws EMSException {

		return true;
	}

}
