package com.cg.ems.service;

import java.util.List;

import com.cg.ems.beans.Employee;
import com.cg.ems.exceptions.EMSException;

//copy all methods same as EmployeeDAO interface
public interface EmployeeService {
	
	public int addEmployee(Employee employee) throws EMSException; //stores employee obj and returns id of type int
	//model provides id after receiving data
	public Employee getEmployee( int id ) throws EMSException; //gives particular obj based on id
	
	public void updateEmployee( Employee employee ) throws EMSException; //should give all details about the employee to update previous employee
	
	public void removeEmployee( int id ) throws EMSException;
	
	public List<Employee> getAllEmployees() throws EMSException;
	
	//validate the Employee
	public boolean isvalid(Employee employee) throws EMSException;
}
