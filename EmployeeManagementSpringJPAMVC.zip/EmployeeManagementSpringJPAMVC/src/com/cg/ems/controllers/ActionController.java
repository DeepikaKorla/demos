package com.cg.ems.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ems.beans.Employee;
import com.cg.ems.exceptions.EMSException;
import com.cg.ems.model.EmployeeDAO;
import com.cg.ems.service.EmployeeService;

@Controller
public class ActionController {
	@Autowired	
	EmployeeService employeeService;
	@Autowired	
	EmployeeDAO employeeDAO;
	@RequestMapping(value="/createEmployee")
	public ModelAndView createEmployee(@Valid@ModelAttribute("employee") Employee employee,BindingResult result) {
		try {
			int empid=employeeService.addEmployee(employee);
			employee.setId(empid);
		} catch (EMSException e) {

			e.printStackTrace();
		}
		return new ModelAndView("addEmployeeSuccess","employee",employee);
	}
	@RequestMapping(value="/getEmployeeDetails")
	public ModelAndView getEmployeeDetails(@Valid@RequestParam("id") int id)  {

		Employee employee = null;
		try {
			employee = employeeService.getEmployee(id);
		} catch (EMSException e) {

			e.printStackTrace();
		}

		return new ModelAndView("getEmployeeDetailsSuccess","employee",employee);
	}
	@RequestMapping(value="/employeeUpdate")
	public ModelAndView updateEmployee(@Valid@ModelAttribute("employee") Employee employee,BindingResult result) {




		try {
			employeeService.updateEmployee(employee);
		} catch (EMSException e) {

			e.printStackTrace();
		}


		return new ModelAndView("updateEmployeeSuccess","employee",employee);
	}

	@RequestMapping(value="/deleteEmployee")
	public ModelAndView deleteEmployee(@Valid@RequestParam("id") int id)  {
		Employee employee = null;
		try {
			employeeService.removeEmployee(id);
		} catch (EMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return new ModelAndView("removeEmployeeSuccess","employee",employee);
	}
	@RequestMapping(value="/getAllEmployees")
	public ModelAndView getAll() {
		List<Employee> employee = null;
		try {
			employee = employeeService.getAllEmployees();
		} catch (EMSException e) {
			e.printStackTrace();
		}
		return  new ModelAndView("getAllEmployees","employee",employee);
	}
}
