package com.cg.ems.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.ems.beans.Employee;



@Controller
public class URIController {
	
	
	
	@ModelAttribute("employee")
	public Employee getEmployee() {
		return new Employee();
	}
	@RequestMapping(value="/")
	public String getIndexPage() {
		return "indexPage";
	}
	@RequestMapping(value="/addEmployee")
	public String getaddEmployee() {
		return "addEmployeePage";
	}
	@RequestMapping(value="/getEmployee")
	public String getEmployeePage() {
		return "getEmployeePage";
	}
	@RequestMapping(value="/updateEmployee")
	public String getupdateEmployee() {
		return "updateEmployeePage";
	}
	@RequestMapping(value="/removeEmployee")
	public String getremoveEmployee() {
		return "removeEmployeePage";
	}
	
//	@RequestMapping(value="getAllEmployees")
//	public String getAllEmployees() {
//		return "getAllEmployees";
//	}

}
